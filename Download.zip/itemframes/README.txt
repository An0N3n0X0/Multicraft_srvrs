MultiCraft Game mod: itemframes
===============================

License of source code
----------------------
Copyright (C) Zeg9
Copyright (C) VanessaE
Copyright (C) 2019-2020 MultiCraft Development Team

https://gitlab.com/VanessaE/homedecor_modpack/tree/master/itemframes

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3.0 of the License.

The complete text of the GNU Lesser General Public 3.0 License can be found at:
http://www.gnu.org/licenses/lgpl-3.0.html

License of textures
-------------------
Copyright (C) 2020 MultiCraft Development Team

Graphics in this mod is NOT free and can only be used as part of the official MultiCraft build.
Allowed to be used in non-official builds ONLY for personal use.
