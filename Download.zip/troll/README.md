# troll

# VERY EXPERIEMENTAL, ALL COMMANDS THAT ARE NOT LISTED: DO NOT WORK!
This is my MT Mod for trolling on Servers.
List of commands:
* /t-smoke: Spawns much of smoke arround the player
* /t-ban: Let the player think that he is banned
* /t-hp: remove 2 hp from a player
* /t-error: Send an Error message to the player
* /t-black: The player see 20 seconds only black
* /t-freeze: the player is freezed
* /t-unfreeze: unfreeze a player or stop t-nogravity
* /t-nogravity: the player has low gravity
* /t-teleport: the player got a random teleport
* /t-jail: A jail is building at the players position
* /t-lava: the player is ina lava block
* /t-hole: the player go down 5 blocks in a hole
* /t-msg: Send a MSG from another player args: <from> <to> <msg>
* /t-mob: Spawns a given amount of mobs at the players position args: <player> <mob> <amount>
* /t-chat <name> <message>: You can send messages as an another player!
* /t-diamond <name>: Spawns much of diamonds arround the player
* /t-shit Spawns much of shit arround the player
* /t-eyes <player>: Spawns much of eyes arround the player
* /t-blackparticles <player>: Spawns much of black particles arround the player
* /t-grant <granter> <player> <priv>: The player thinks, he got privs
* /t-chat <sender> <message>: Send something in the chat with another name!
* /t-msg <fromstring> <toplayer> <msgstring>: Send an msg from another player


