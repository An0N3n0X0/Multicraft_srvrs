## LICENSE

* MIT

Author and creator of the mod:

* Copyright (C) 2024 SkyBuilder1717 MIT

Contributors:

* Copyright (C) 2024 mckaygerhard

see [LICENSE](LICENSE) file.

Media:

* textures/*.png - Copyright (C) 2024 SkyBuilder1717
* sounds/*.png - Copyright (C) 2024 SkyBuilder1717
