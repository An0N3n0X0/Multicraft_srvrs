
# item_physics
Makes items not spin when they are on the floor.

