MultiCraft Game mod: flowerpot
==============================

License of source code
----------------------
Copyright (C) 2015-2017 Auke Kok <sofar@foo-projects.org>
Copyright (C) 2019-2020 MultiCraft Development Team

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3.0 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-3.0.html

License of model
----------------
Copyright (C) 2015-2017 Auke Kok <sofar@foo-projects.org> (CC-BY-SA-3.0)
Copyright (C) 2020 MultiCraft Development Team (CC-BY-SA-3.0)

License of textures
-------------------
Copyright (C) 2020 MultiCraft Development Team

Graphics in this mod is NOT free and can only be used as part of the official MultiCraft build.
Allowed to be used in non-official builds ONLY for personal use.
