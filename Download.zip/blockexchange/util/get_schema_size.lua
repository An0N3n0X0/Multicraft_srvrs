
function blockexchange.get_schema_size(schema)
    return {
        x = schema.size_x,
        y = schema.size_y,
        z = schema.size_z
    }
end