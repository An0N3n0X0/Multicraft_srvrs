function blockexchange.log(level, msg)
    minetest.log(level, "[blockexchange] " .. msg)
end