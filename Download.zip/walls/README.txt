Minetest Game mod: walls
========================
See license.txt for license information.

Authors of source code
----------------------
Auke Kok <sofar@foo-projects.org> (LGPLv3.0+)
Shara RedCat (LGPLv3.0+)
MultiCraft Development Team (LGPLv3.0+)
