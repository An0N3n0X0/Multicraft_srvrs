MultiCraft Game mod: flowers
============================
See license.txt for license information.

Authors of source code
----------------------
Originally by Ironzorg (MIT) and VanessaE (MIT)
Various Minetest developers and contributors (MIT)

Authors of textures
-------------------
MultiCraft Development Team

Graphics in this mod is NOT free and can be used only as part of the official MultiCraft build.
Allowed to be used in non-official builds ONLY for personal use.
