MutliCraft Game mod: toolranks
==============================
See license.txt for license information.

Tool gains levels for digging nodes. Higher level tools take longer to
wear out.

https://github.com/lisacvuk/minetest-toolranks
https://notabug.org/TenPlus1/toolranks

Authors of source code
----------------------
lisacvuk (LGPLv3.0+)
TenPlus1 (LGPLv3.0+)
MultiCraft Development Team (LGPLv3.0+)

Authors of sounds
-----------------
Cabeeno Rossley (CC BY 3.0)
https://freesound.org/people/Cabeeno%20Rossley/sounds/126422/
  toolranks_levelup.ogg
