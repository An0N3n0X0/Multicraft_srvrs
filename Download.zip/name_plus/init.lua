local player_colors = {}
local tags = {}

local color_file = minetest.get_worldpath() .. "/player_colors.txt"
local tag_file = minetest.get_worldpath() .. "/player_tags.txt"

local supported_colors = {
    red = "#FF0000", dark_red = "#8B0000", green = "#00FF00", dark_green = "#006400",
    blue = "#00BFFF", dark_blue = "#00008B", yellow = "#FFFF00", orange = "#FFA500",
    purple = "#AA00FF", pink = "#FF69B4", cyan = "#00FFFF", white = "#FFFFFF",
    gray = "#808080", black = "#000000", brown = "#A52A2A", gold = "#FFD700",
    lime = "#BFFF00", aqua = "#7FFFD4"
}

local function sanitize_color(color)
    if not color then return "#FFFFFF" end
    if not color:match("^#%x%x%x%x%x%x$") then return "#FFFFFF" end
    return color
end

local function load_data()
    local f = io.open(color_file, "r")
    if f then
        for line in f:lines() do
            local name, color = line:match("([^=]+)=([^=]+)")
            if name and color then
                player_colors[name] = color
            end
        end
        f:close()
    end

    local f2 = io.open(tag_file, "r")
    if f2 then
        for line in f2:lines() do
            local name, data = line:match("([^=]+)=([^=]+)")
            if name and data then
                local tag, color = data:match("([^,]+),(.+)")
                if tag and color then
                    tags[name] = { tag = tag, color = color }
                end
            end
        end
        f2:close()
    end
end

local function save_colors()
    local f = io.open(color_file, "w")
    for name, color in pairs(player_colors) do
        f:write(name .. "=" .. color .. "\n")
    end
    f:close()
end

local function save_tags()
    local f = io.open(tag_file, "w")
    for name, data in pairs(tags) do
        f:write(name .. "=" .. data.tag .. "," .. data.color .. "\n")
    end
    f:close()
end

local function update_nametag(player)
    local name = player:get_player_name()
    local color = sanitize_color(player_colors[name])
    local tag_data = tags[name]

    local full_text = ""
    if tag_data then
        full_text = minetest.colorize(tag_data.color, "[" .. tag_data.tag .. "] ") ..
                    minetest.colorize(color, name)
    else
        full_text = minetest.colorize(color, name)
    end

    player:set_nametag_attributes({ text = full_text })
end

minetest.register_on_joinplayer(function(player)
    update_nametag(player)
end)

minetest.register_on_chat_message(function(name, message)
    local tag = tags[name]
    local color = sanitize_color(player_colors[name])
    local text = ""

    if tag then
        text = minetest.colorize(tag.color, "[" .. tag.tag .. "] ") ..
               minetest.colorize(color, "<" .. name .. "> ")
    else
        text = minetest.colorize(color, "<" .. name .. "> ")
    end

    minetest.chat_send_all(text .. message)
    return true
end)

local function get_formspec()
    local fs = "formspec_version[4]size[10,6]label[0.3,0.2;İsim renginizi seçin:]"
    local x, y, i = 0.3, 0.8, 0
    for name, hex in pairs(supported_colors) do
        fs = fs .. string.format("button[%f,%f;2,0.8;color_%s;%s]", x, y, name, minetest.colorize(hex, name))
        x = x + 2.1; i = i + 1
        if i % 4 == 0 then x = 0.3 y = y + 1.0 end
    end
    return fs
end

minetest.register_chatcommand("color", {
    description = "İsim rengi seç",
    func = function(name)
        minetest.show_formspec(name, "nametag_plus:color", get_formspec())
        return true
    end
})

minetest.register_on_player_receive_fields(function(player, formname, fields)
    if formname ~= "nametag_plus:color" then return end
    local name = player:get_player_name()
    for field, _ in pairs(fields) do
        local chosen = field:match("color_(.+)")
        if chosen and supported_colors[chosen] then
            player_colors[name] = supported_colors[chosen]
            save_colors()
            update_nametag(player)
            minetest.chat_send_player(name, "✅ Renk güncellendi!")
            return
        end
    end
end)

minetest.register_privilege("settags", {
    description = "Etiket (tag) ayarlama yetkisi",
    give_to_singleplayer = true
})

minetest.register_chatcommand("set_tag", {
    params = "<oyuncu> <tag> <renk>",
    description = "Oyuncuya etiket ver (renk adı veya hex kodu)",
    privs = { settags = true },
    func = function(sender, param)
        local target, tag, color_input = param:match("^(%S+)%s+(%S+)%s+(%S+)$")
        if not (target and tag and color_input) then
            return false, "❌ Kullanım: /set_tag <oyuncu> <tag> <renk (örnek: red veya #FF0000)>"
        end

        local player = minetest.get_player_by_name(target)
        if not player then
            return false, "❌ Oyuncu çevrimdışı."
        end

        local final_color = supported_colors[color_input]
        if not final_color and color_input:match("^#%x%x%x%x%x%x$") then
            final_color = color_input
        end

        if not final_color then
            return false, "❌ Geçersiz renk! Renk adı (örnek: red, blue) veya hex kodu (#RRGGBB) girin."
        end

        tags[target] = { tag = tag, color = final_color }
        save_tags()
        update_nametag(player)
        return true, "✅ " .. target .. " oyuncusuna [" .. tag .. "] etiketi verildi!"
    end
})

load_data()