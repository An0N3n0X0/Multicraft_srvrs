MultiCraft Game mod: dungeon_loot
=================================
See license.txt for license information.

Adds randomly generated chests with some "loot" to generated dungeons,
an API to register additional loot is provided.
Only works if dungeons are actually enabled in mapgen flags.

Authors of source code
----------------------
Originally by sfan5 (MIT)
