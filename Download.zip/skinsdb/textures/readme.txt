This location is where you can put your custom skins.


List of accepted texture names
------------------------------

Public skin available for all users:
	character.[number or name].png
	^ The allowed characters in "[number or name]" are "[A-z0-9_.-]+".

One or multiple private skins for player "[nick]":
	player.[nick].png
	player.[nick].[number or name].png

Skin previews for public and private skins:
	character.[number or name].preview.png
	player.[nick].preview.png
	player.[nick].[number or name].preview.png

	Note: This is optional and overrides automatically generated preciewws.


Legacy texture names
--------------------

The character `_` is accepted in player names, thus it is not recommended to
use such file names. For compatibility reasons, they are still recognized.

	character_[number or name].png
	player_[nick].png
	player_[nick]_[number or name].png

... and corresponding previews that end in `_preview.png`.
