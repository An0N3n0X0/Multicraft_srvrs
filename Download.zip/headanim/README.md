# Headanim
[![ContentDB](https://content.minetest.net/packages/Lone_Wolf/headanim/shields/downloads/)](https://content.minetest.net/packages/Lone_Wolf/headanim/)

Makes player heads follow their look dir in Minetest. Requires version 5.3+

## Similar mods
* https://github.com/minetest-mods/playeranim: A lot more complex (and possibly slower?) than Headanim but looks nicer as a result
