MultiCraft Game mod: bucket
===========================
See license.txt for license information.

Authors of source code
----------------------
Kahrl <kahrl@gmx.net> (LGPLv3.0+)
celeron55, Perttu Ahola <celeron55@gmail.com> (LGPLv3.0+)
Various Minetest developers and contributors (LGPLv3.0+)
MultiCraft Development Team (LGPLv3.0+)

Authors of media (textures)
---------------------------
Copyright (C) MultiCraft Development Team

Graphics in this mod is NOT free and can be used only as part of the official MultiCraft build.
Allowed to be used in non-official builds ONLY for personal use.
