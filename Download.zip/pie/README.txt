MultiCraft Game mod: pie
========================
See license.txt for license information.

Pie mod adds cakes and pies to the game.
https://forum.minetest.net/viewtopic.php?f=9&t=13285

License of source code:
-----------------------
Copyright (C) 2016 TenPlus1 (MIT)
