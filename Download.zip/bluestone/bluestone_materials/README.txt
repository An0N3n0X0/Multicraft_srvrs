MultiCraft Game mod: bluestone materials
========================================

License of source code
----------------------
Copyright (C) 2019 MultiCraft Development Team

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3.0 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-3.0.html

License of textures
-------------------
Copyright (C) 2016-2021 MultiCraft Development Team

Graphics in this mod is NOT free and can be used only as part of the official MultiCraft build.
Allowed to be used in non-official builds ONLY for personal use.
