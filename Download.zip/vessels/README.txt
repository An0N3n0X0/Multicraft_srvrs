MultiCraft Game mod: vessels
============================
See license.txt for license information.

Authors of source code
----------------------
Originally by Vanessa Ezekowitz (LGPLv3.0+)
Modified by Perttu Ahola <celeron55@gmail.com> (LGPLv3.0+)
Various Minetest developers and contributors (LGPLv3.0+)
MultiCraft Development Team (LGPLv3.0+)

License of textures
-------------------
Copyright (C) MultiCraft Development Team

Graphics in this mod is NOT free and can only be used as part of the official MultiCraft build.
Allowed to be used in non-official builds ONLY for personal use.
