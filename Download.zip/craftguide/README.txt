MultiCraft Game mod: craftguide
===============================
See license.txt for license information.

Adds a Сrafting Guide with instructions on crafting and cooking all registered items.

License of source code:
-----------------------
Copyright (C) 2015-2019 Jean-Patrick Guerrero and contributors.
Copyright (C) 2019 pauloue
