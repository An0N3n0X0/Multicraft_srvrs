MultiCraft Game mod: farming
============================
See license.txt for license information.

Authors of source code
----------------------
Originally by PilzAdam (MIT)
webdesigner97 (MIT)
Various Minetest developers and contributors (MIT)
MultiCraft Development Team (MIT)
